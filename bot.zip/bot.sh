#!/bin/bash
clear
pass="susu sapi"
until [ "$pwd" = "$pass" ]
do
read -p "silahkan masukan passwordnya kak :" pwd
clear
done
sleep 1
    echo "___________________________________"
   echo "!¡tools by firman yt |             ¡!"
   echo "¡¡subscribe channel Firman YT|     ¡¡"
   echo "!¡_________________________________!!"
   echo "--------List Menu||firman yt---------"
   echo "¡¡{1}Buat Whatsapp Bot               ¡¡"
   echo "¡¡{2}REDHAWK                         ¡¡"
   echo "¡¡{3}Ddos Hammer                     ¡¡"
   echo "!!___________________________________!!"
read -p "Masukan Pilihan Anda Disini :" pilih
if [ $pilih = "1" ]
then
    echo "memulai penginstallan whatsapp bot!!"
cd $HOME
pkg update && pkg upgrade
pkg install git
pkg install wget
git clole https://github.com/firman717/botf7
cd botf7
pkg install unzip
unzip rikabot.zip
cd rikabot
cd rikabot
pkg install ffmpeg
pkg install nodejs
pkh install tesseract
npm i -g cwebp
npm i node-tesseract-ocr
npm i -g ytdl
npm i
npm i got
node index.js
elif [ "$pilih" = "2" ]
then
    echo "memulai tools Redhawk"
pkg update && pkg upgrade
pkg install git
pkg install php
git clone https://github.com/Tuhinshubhra/RED_HAWK
cd RED_HAWK
chmod +x rhawk.php
php rhawk.php
elif [ "$pilih" = "3" ]
then
   echo "memulai penginstallan Ddos Hammer"
pkg update
pkg upgrade
pkg install python
pkg install git
git clone https://github.com/cyweb/hammer
cd hammer
python hammer.py
   echo "untuk cara menjalankannya ketik"
   echo "python hammer.py -s ip target -p 80 -t 135"
else
    echo "Maaf input yang anda masukan salah!!"
    echo "silahkan ulang tools kembali...."
fi
